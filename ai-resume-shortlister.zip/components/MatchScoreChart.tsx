
import React from 'react';

interface MatchScoreChartProps {
  score: number;
}

const MatchScoreChart: React.FC<MatchScoreChartProps> = ({ score }) => {
  const radius = 52;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (score / 100) * circumference;

  const getScoreColor = (s: number) => {
    if (s < 40) return 'text-red-500';
    if (s < 75) return 'text-yellow-400';
    return 'text-green-500';
  };

  const getTrackColor = (s: number) => {
    if (s < 40) return 'stroke-red-500';
    if (s < 75) return 'stroke-yellow-400';
    return 'stroke-green-500';
  }

  return (
    <div className="relative flex items-center justify-center w-36 h-36">
      <svg className="w-full h-full" viewBox="0 0 120 120">
        <circle
          className="text-gray-700 stroke-current"
          strokeWidth="8"
          fill="transparent"
          r={radius}
          cx="60"
          cy="60"
        />
        <circle
          className={`${getTrackColor(score)} stroke-current transition-all duration-1000 ease-in-out`}
          strokeWidth="8"
          strokeLinecap="round"
          fill="transparent"
          r={radius}
          cx="60"
          cy="60"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          transform="rotate(-90 60 60)"
        />
      </svg>
      <div className={`absolute flex flex-col items-center justify-center ${getScoreColor(score)}`}>
        <span className="text-4xl font-bold">{score}</span>
        <span className="text-sm font-medium">% Match</span>
      </div>
    </div>
  );
};

export default MatchScoreChart;
