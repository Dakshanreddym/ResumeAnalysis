
import React from 'react';

interface LoaderProps {
  text?: string;
  subtext?: string;
}

const Loader: React.FC<LoaderProps> = ({ 
  text = "Analyzing, please wait...", 
  subtext = "Our AI assistant is reviewing the documents." 
}) => {
  return (
    <div className="flex flex-col items-center justify-center p-8 text-center bg-gray-800 rounded-lg shadow-lg border border-gray-700">
      <div className="w-12 h-12 border-4 border-t-transparent border-cyan-400 rounded-full animate-spin"></div>
      <p className="mt-4 text-lg font-semibold text-gray-300">{text}</p>
      <p className="text-sm text-gray-400">{subtext}</p>
    </div>
  );
};

export default Loader;
