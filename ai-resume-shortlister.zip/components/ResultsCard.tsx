
import React from 'react';
import { AnalysisResult, InterviewQuestionCategory } from '../types';
import MatchScoreChart from './MatchScoreChart';
import SkillBadge from './SkillBadge';
import InterviewQuestions from './InterviewQuestions';
import ErrorMessage from './ErrorMessage';

interface ResultsCardProps {
  result: AnalysisResult;
  onGenerateQuestions: () => void;
  isGeneratingQuestions: boolean;
  interviewQuestions: InterviewQuestionCategory[] | null;
  questionGenerationError: string | null;
}

const InfoCard: React.FC<{ title: string; icon: React.ReactElement; children: React.ReactNode }> = ({ title, icon, children }) => (
    <div className="bg-gray-800/50 rounded-lg p-4 ring-1 ring-white/10 h-full">
        <h3 className="text-lg font-semibold text-cyan-400 flex items-center mb-3">
            {icon}
            <span className="ml-2">{title}</span>
        </h3>
        {children}
    </div>
);

const ResultsCard: React.FC<ResultsCardProps> = ({ result, onGenerateQuestions, isGeneratingQuestions, interviewQuestions, questionGenerationError }) => {
  return (
    <div className="bg-gray-800 p-6 rounded-xl shadow-2xl border border-gray-700 w-full animate-fade-in">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-1 flex flex-col items-center justify-center bg-gray-900/50 p-6 rounded-lg ring-1 ring-white/10">
                <h2 className="text-xl font-bold text-white mb-4">Overall Match Score</h2>
                <MatchScoreChart score={result.match_score} />
            </div>

            <div className="md:col-span-2 bg-gray-900/50 p-6 rounded-lg ring-1 ring-white/10 flex flex-col justify-center">
                <h2 className="text-xl font-bold text-white mb-2">Summary & Recommendation</h2>
                <p className="text-gray-300 leading-relaxed text-center md:text-left">{result.short_summary}</p>
            </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
            <InfoCard title="Skills Matched" icon={<CheckCircleIcon />}>
                <div className="flex flex-wrap gap-2">
                    {result.skills_matched.length > 0 ? (
                        result.skills_matched.map((s, i) => (
                            <SkillBadge key={i} skill={s.skill} level={s.level} colors={result.ui_hints.badge_colors} />
                        ))
                    ) : (
                        <p className="text-gray-400">No matching skills found.</p>
                    )}
                </div>
            </InfoCard>

            <InfoCard title="Missing Skills" icon={<XCircleIcon />}>
                <div className="flex flex-wrap gap-2">
                    {result.missing_skills.length > 0 ? (
                        result.missing_skills.map((skill, i) => (
                            <div key={i} className="bg-red-900/50 text-red-300 px-3 py-1 text-sm font-medium rounded-full border border-red-500/50">{skill}</div>
                        ))
                    ) : (
                         <p className="text-gray-400">No significant skill gaps identified.</p>
                    )}
                </div>
            </InfoCard>
        </div>

        <div className="mt-6">
            <InfoCard title="Relevant Experience" icon={<ClipboardListIcon />}>
                <ul className="space-y-2 list-disc list-inside text-gray-300">
                    {result.experience_matched.length > 0 ? (
                        result.experience_matched.map((exp, i) => (
                            <li key={i}>{exp}</li>
                        ))
                    ) : (
                        <p className="text-gray-400">No directly relevant experience highlighted.</p>
                    )}
                </ul>
            </InfoCard>
        </div>

        <div className="mt-8 border-t border-gray-700 pt-6">
            {!interviewQuestions && (
                 <div className="text-center">
                    <button
                        onClick={onGenerateQuestions}
                        disabled={isGeneratingQuestions}
                        className="px-6 py-2 font-semibold text-white bg-gradient-to-r from-teal-500 to-cyan-600 rounded-md hover:from-teal-600 hover:to-cyan-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-cyan-500 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        {isGeneratingQuestions ? 'Generating Questions...' : 'Generate Interview Questions'}
                    </button>
                 </div>
            )}
            {isGeneratingQuestions && !interviewQuestions && (
                 <div className="flex items-center justify-center text-gray-400 mt-4">
                    <div className="w-5 h-5 border-2 border-t-transparent border-cyan-400 rounded-full animate-spin mr-2"></div>
                    <span>AI is crafting questions...</span>
                 </div>
            )}
            {questionGenerationError && <div className="mt-4"><ErrorMessage message={questionGenerationError} /></div>}
            {interviewQuestions && <InterviewQuestions categories={interviewQuestions} />}
        </div>
    </div>
  );
};

// SVG Icons
const CheckCircleIcon: React.FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
);

const XCircleIcon: React.FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
);

const ClipboardListIcon: React.FC = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
    </svg>
);

export default ResultsCard;
