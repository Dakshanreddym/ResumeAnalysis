
import React, { useState } from 'react';
import { InterviewQuestionCategory } from '../types';

interface InterviewQuestionsProps {
    categories: InterviewQuestionCategory[];
}

const InterviewQuestions: React.FC<InterviewQuestionsProps> = ({ categories }) => {
    const [copied, setCopied] = useState<Record<string, boolean>>({});

    const handleCopy = (text: string, id: string) => {
        navigator.clipboard.writeText(text);
        setCopied(prev => ({...prev, [id]: true }));
        setTimeout(() => {
            setCopied(prev => ({ ...prev, [id]: false }));
        }, 2000);
    };

    return (
        <div className="animate-fade-in">
            <h3 className="text-xl font-bold text-white mb-4 text-center">Generated Interview Questions</h3>
            <div className="space-y-4">
                {categories.map((category, catIndex) => (
                    <div key={catIndex} className="bg-gray-900/50 p-4 rounded-lg ring-1 ring-white/10">
                        <h4 className="font-semibold text-cyan-400 mb-3">{category.category}</h4>
                        <ul className="space-y-3">
                            {category.questions.map((question, qIndex) => {
                                const questionId = `${catIndex}-${qIndex}`;
                                return (
                                    <li key={qIndex} className="flex items-start justify-between gap-2 text-gray-300">
                                        <span className="flex-1">{question}</span>
                                        <button 
                                            onClick={() => handleCopy(question, questionId)}
                                            className="p-1.5 rounded-md bg-gray-700/50 hover:bg-gray-700 transition text-gray-400 hover:text-white"
                                            aria-label="Copy question"
                                        >
                                            {copied[questionId] ? (
                                                <CheckIcon />
                                            ) : (
                                                <ClipboardIcon />
                                            )}
                                        </button>
                                    </li>
                                );
                            })}
                        </ul>
                    </div>
                ))}
            </div>
        </div>
    );
};

const ClipboardIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
    </svg>
);

const CheckIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-green-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
    </svg>
);


export default InterviewQuestions;
