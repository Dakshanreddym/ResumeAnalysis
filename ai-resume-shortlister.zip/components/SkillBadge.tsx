import React from 'react';

interface SkillBadgeProps {
  skill: string;
  level: string;
  colors: {
    Expert: string;
    Intermediate: string;
    Beginner: string;
  };
}

const SkillBadge: React.FC<SkillBadgeProps> = ({ skill, level, colors }) => {
  // FIX: Use the `colors` prop from the API response to dynamically style badges, with fallbacks.
  const getLevelColor = () => {
    switch (level.toLowerCase()) {
      case 'expert':
        return colors.Expert || 'bg-green-500/20 text-green-300 border-green-500/50';
      case 'intermediate':
        return colors.Intermediate || 'bg-yellow-500/20 text-yellow-300 border-yellow-500/50';
      case 'beginner':
        return colors.Beginner || 'bg-red-500/20 text-red-300 border-red-500/50';
      default:
        return 'bg-gray-500/20 text-gray-300 border-gray-500/50';
    }
  };

  return (
    <div className={`flex items-center px-3 py-1 text-sm font-medium rounded-full border ${getLevelColor()}`}>
      <span>{skill}</span>
      <span className="ml-2 text-xs opacity-70">({level})</span>
    </div>
  );
};

export default SkillBadge;