
import React from 'react';

interface ErrorMessageProps {
  message: string;
}

const ErrorMessage: React.FC<ErrorMessageProps> = ({ message }) => {
  return (
    <div className="p-4 bg-red-900/50 border border-red-500/50 text-red-200 rounded-lg shadow-lg" role="alert">
      <h3 className="font-bold text-lg">Analysis Failed</h3>
      <p className="text-sm">{message}</p>
    </div>
  );
};

export default ErrorMessage;
