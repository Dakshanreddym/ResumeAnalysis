
import { GoogleGenAI, Type } from "@google/genai";
import { AnalysisResult, InterviewQuestionCategory } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const analysisSchema = {
  type: Type.OBJECT,
  properties: {
    match_score: { 
      type: Type.INTEGER,
      description: "A score from 0 to 100 representing how well the resume matches the job description."
    },
    skills_matched: {
      type: Type.ARRAY,
      description: "A list of skills from the resume that match the job description.",
      items: {
        type: Type.OBJECT,
        properties: {
          skill: { type: Type.STRING, description: "The name of the skill." },
          level: { type: Type.STRING, description: "The candidate's expertise level (e.g., Beginner, Intermediate, Expert)." },
        },
        required: ['skill', 'level'],
      },
    },
    experience_matched: {
      type: Type.ARRAY,
      description: "A summary of relevant work experience, projects, or achievements.",
      items: { type: Type.STRING },
    },
    missing_skills: {
      type: Type.ARRAY,
      description: "Important skills from the job description that are not found in the resume.",
      items: { type: Type.STRING },
    },
    short_summary: { 
      type: Type.STRING,
      description: "A one or two-sentence recommendation on whether to shortlist the candidate."
    },
    ui_hints: {
      type: Type.OBJECT,
      description: "Suggestions for how to render the analysis in a user interface.",
      properties: {
        highlight_skills: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
        },
        badge_colors: {
          type: Type.OBJECT,
          description: "Tailwind CSS class strings for different skill levels.",
          properties: {
            Expert: { type: Type.STRING, description: "Tailwind classes for 'Expert' level badges. E.g., 'bg-green-500/20 text-green-300 border-green-500/50'" },
            Intermediate: { type: Type.STRING, description: "Tailwind classes for 'Intermediate' level badges. E.g., 'bg-yellow-500/20 text-yellow-300 border-yellow-500/50'" },
            Beginner: { type: Type.STRING, description: "Tailwind classes for 'Beginner' level badges. E.g., 'bg-red-500/20 text-red-300 border-red-500/50'" },
          },
        },
        match_score_chart: { type: Type.STRING },
      },
    },
  },
  required: [
    'match_score',
    'skills_matched',
    'experience_matched',
    'missing_skills',
    'short_summary',
    'ui_hints',
  ],
};

const questionsSchema = {
    type: Type.ARRAY,
    description: "A list of categorized interview questions.",
    items: {
        type: Type.OBJECT,
        properties: {
            category: { type: Type.STRING, description: "The category of the questions (e.g., Technical Deep Dive, Behavioral, Culture Fit, Probing Missing Skills)." },
            questions: {
                type: Type.ARRAY,
                description: "A list of interview questions for this category.",
                items: { type: Type.STRING }
            }
        },
        required: ['category', 'questions']
    }
};

const ANALYSIS_SYSTEM_INSTRUCTION = `You are an expert HR assistant and NLP analyst. Your job is to analyze resumes against job descriptions and produce structured, actionable insights.
The output should be accurate, concise, visually interpretable for a dashboard or web UI, and clear enough to highlight strengths, gaps, and recommendations at a glance.
Analyze the resume and produce the following outputs in JSON format suitable for UI display.
`;

const QUESTIONS_SYSTEM_INSTRUCTION = `You are a senior hiring manager and an expert technical interviewer. Based on the provided job description, candidate resume, and a pre-analysis, generate a set of insightful and relevant interview questions. The questions should be designed to effectively evaluate the candidate's skills, experience, and suitability for the role. The questions should be categorized logically.`;


export const analyzeResume = async (jobDescription: string, resume: string): Promise<AnalysisResult> => {
  try {
    const userPrompt = `I have a job description and a candidate resume. Analyze the resume and produce the required JSON output.

Job Description:
---
${jobDescription}
---

Candidate Resume:
---
${resume}
---
`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: userPrompt,
      config: {
        systemInstruction: ANALYSIS_SYSTEM_INSTRUCTION,
        responseMimeType: "application/json",
        responseSchema: analysisSchema,
        temperature: 0.2,
      },
    });

    const jsonText = response.text.trim();
    const cleanedJsonText = jsonText.replace(/^```json\s*|```$/g, '');
    const result: AnalysisResult = JSON.parse(cleanedJsonText);
    return result;
  } catch (error) {
    console.error("Error analyzing resume:", error);
    if (error instanceof Error) {
        throw new Error(`Failed to analyze resume. Please check the inputs and try again. Details: ${error.message}`);
    }
    throw new Error("An unknown error occurred during resume analysis.");
  }
};

export const generateInterviewQuestions = async (jobDescription: string, resume: string, analysis: AnalysisResult): Promise<InterviewQuestionCategory[]> => {
    try {
        const userPrompt = `
Job Description:
---
${jobDescription}
---

Candidate Resume:
---
${resume}
---

Initial AI Analysis Summary:
---
- Overall Match Score: ${analysis.match_score}%
- Matched Skills: ${analysis.skills_matched.map(s => `${s.skill} (${s.level})`).join(', ')}
- Missing Skills: ${analysis.missing_skills.join(', ')}
- Summary: ${analysis.short_summary}
---

Based on all the provided information, generate a categorized list of interview questions. The questions should probe the matched skills to verify depth, investigate the missing skills to gauge awareness or related experience, and explore their overall experience for behavioral insights.
`;

        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: userPrompt,
            config: {
                systemInstruction: QUESTIONS_SYSTEM_INSTRUCTION,
                responseMimeType: "application/json",
                responseSchema: questionsSchema,
                temperature: 0.5,
            }
        });

        const jsonText = response.text.trim();
        const cleanedJsonText = jsonText.replace(/^```json\s*|```$/g, '');
        const result: InterviewQuestionCategory[] = JSON.parse(cleanedJsonText);
        return result;

    } catch (error) {
        console.error("Error generating interview questions:", error);
        if (error instanceof Error) {
            throw new Error(`Failed to generate questions. Details: ${error.message}`);
        }
        throw new Error("An unknown error occurred during question generation.");
    }
};
